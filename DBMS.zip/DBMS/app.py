from flask import Flask, render_template, request, redirect, url_for
import mysql.connector
import os

app = Flask(__name__)

# Ensure the upload folder exists
UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# MySQL DB connection
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="2424",
    database="DB"
)
cursor = conn.cursor(dictionary=True)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/animals')
def show_animals():
    cursor.execute("SELECT * FROM Animal")
    animals = cursor.fetchall()
    return render_template("animals.html", animals=animals)

@app.route('/adopters')
def show_adopters():
    cursor.execute("SELECT * FROM Adopter")
    adopters = cursor.fetchall()
    return render_template("adopters.html", adopters=adopters)

@app.route('/add-animal', methods=['GET', 'POST'])
def add_animal():
    if request.method == 'POST':
        image = request.files['image']
        image_filename = image.filename
        image_path = os.path.join(UPLOAD_FOLDER, image_filename)
        image.save(image_path)

        data = (
            request.form['AnimalId'],
            request.form['Name'],
            request.form['Species'],
            request.form['Breed'],
            request.form['Age'],
            request.form['HealthStatus'],
            request.form['VaccinationStatus'],
            request.form['Description'],
            image_filename
        )

        cursor.execute("""
            INSERT INTO Animal (AnimalId, Name, Species, Breed, Age, HealthStatus, VaccinationStatus, Description, ImagePath)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, data)
        conn.commit()
        return redirect(url_for('show_animals'))
    return render_template('add_animal.html')

@app.route('/add_adopter', methods=['GET', 'POST'])
def add_adopter():
    if request.method == 'POST':
        data = (
            request.form['AdopterId'],
            request.form['FirstName'],
            request.form['LastName'],
            request.form['PhoneNumber'],
            request.form['Email'],
            request.form['Address'],
            request.form['AdoptionDate'],
            request.form['PreferredAnimal']
        )
        cursor.execute("""
            INSERT INTO Adopter (AdopterId, FirstName, LastName, PhoneNumber, Email, Address, AdoptionDate, PreferredAnimal)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """, data)
        conn.commit()
        return redirect(url_for('show_adopters'))
    return render_template('add_adopter.html')

if __name__ == "__main__":
    app.run(debug=True)
